// Pack-Libares — C++ utility library
// Автор: Ilya (Ks993416)
// Лицензия: см. LICENSE

#include <stdio.h>
#include <math.h>
#include <cstdint>

namespace fds {
    void sin_f(float a1){
        sin(a1);
    }
    
    int uint96(float x, float y){ // Not is uint96_t this prank broo =)
        uint32_t fd = x;
        uint64_t fs = y;
        return fd + fs;

    }

    int div(int x1, int y1){
        if(x1 == 0 || y1 == 0){
            printf("error");
            return 0;
        }

        else {
            return x1 / y1;
        }
    }
}